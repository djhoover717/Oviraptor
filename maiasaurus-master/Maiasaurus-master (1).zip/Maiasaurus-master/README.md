# Maiasaurus
Describing exoplanetary system architectures using information theory

This repository contains source code used for Gilbert & Fabrycky (2020), "An information theoretic framework for classifying exoplanetary system architectures" (https://arxiv.org/abs/2003.11098)

The functions used to calculated system-level measures are contained in the python scripts "LMC.py" and "archinfo.py"
